package com.example.taskmanagerapicalling.models.remote.responses.getTasksResponse


class GetTasksResponseModel : ArrayList<GetTasksResponseModelItem>()